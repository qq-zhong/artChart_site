package com.lab.artchart.database

data class User(
    val username: String = "",
    var profilePictureUrl: String = ""
)
