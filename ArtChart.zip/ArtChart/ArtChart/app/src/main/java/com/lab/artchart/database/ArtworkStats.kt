package com.lab.artchart.database

data class ArtworkStats(
    val averageRating: Float,
    val reviewCount: Int
)
